
/*********************************************************************************
*  WEB322 – Assignment 02
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part *  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students.
* 
*  Name:Diogo Watson Manhaes de Andrade Student ID: 104176169 Date: Setember 15, 2017*
*
*  Online (Heroku) Link: https://webaaa.herokuapp.com/
*
********************************************************************************/ 



var express = require('express');
var path = require("path")
var app = express();



//variable to declare HOME path
var home = path.join(__dirname,'views/home.html');

//variable to declare About path
var about = path.join(__dirname,'views/about.html');


//router to render html.home
app.get('/', function(req, res){
    console.log("Got a GET request for the home page");
    res.sendFile(home);
})


//router to render html.about
app.get('/about', function(req, res){
    console.log("got a GET request for the homepage");
    res.sendFile(about);
})


//to use the css file
app.use(express.static('public'));

var configPort = process.env.PORT||8080;

var server = app.listen(configPort, function(){
    var host = server.address().address
    var port = server.address().port


    console.log("express app listening on port", host, port)
})